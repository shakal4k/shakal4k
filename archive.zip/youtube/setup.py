from cx_Freeze import setup, Executable

setup(name="testovaya_version", version=11, executables=[Executable("test.py")])
